var searchData=
[
  ['r_5foop_6',['R_OOP',['../namespace_r___o_o_p.html',1,'']]]
];
