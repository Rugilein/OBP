var searchData=
[
  ['dispose_17',['Dispose',['../class_o_o_p__5_1_1_form1.html#afd2c7698b9bae043e44ea9d4647884db',1,'OOP_5.Form1.Dispose()'],['../class_o_o_p__5_1_1p_admin.html#ab78cf43ecb6917ff71a079db000ad43c',1,'OOP_5.pAdmin.Dispose()']]]
];
