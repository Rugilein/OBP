var searchData=
[
  ['sql_7',['SQL',['../class_r___o_o_p_1_1_s_q_l.html',1,'R_OOP']]]
];
