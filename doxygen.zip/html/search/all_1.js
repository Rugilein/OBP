var searchData=
[
  ['category_1',['Category',['../class_r___o_o_p_1_1_category.html',1,'R_OOP']]]
];
