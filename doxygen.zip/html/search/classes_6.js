var searchData=
[
  ['sql_15',['SQL',['../class_o_o_p__5_1_1_s_q_l.html',1,'OOP_5']]]
];
